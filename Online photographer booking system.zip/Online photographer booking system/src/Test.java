import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class Test {
public static void main(String[] args) {
	LocalDate date = LocalDate.now();
	DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
	System.out.println(date.format(formatter));
	
	int randomPIN = (int)(Math.random()*9000)+1000;
	String PINString = String.valueOf(randomPIN);
	System.out.println(PINString);
    //Store integer in a string
    
	
//	String id = String.format("%04d", random.nextInt(10000));
	
}
}
